package com.example.bitmap.ui


import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.bitmap.R
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.util.*

open class EditBook : AppCompatActivity() {

    private lateinit var imageViewEdit: ImageView
    private lateinit var addImg: ImageButton
    private lateinit var spinnerCatEdit: Spinner
    private lateinit var bookNameEdit: EditText
    private lateinit var authorNameEdit: EditText
    private lateinit var releaseYearEdit: EditText
    private lateinit var pagesEdit: EditText
    private lateinit var update: Button
    private lateinit var actionBar: ActionBar
    private lateinit var books: Book
    private lateinit var db: MyDataBase
    val SELECT_PHOTO = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_book)
        db = MyDataBase(this)
        val i = intent
        books = (i.getSerializableExtra("Book") as Book?)!!

        actionBar()
        initViews()
        val category: ArrayList<String> = db.getCategoryName()
        val categoryId: ArrayList<Int> = db.getCategoryById()
        val adapter = ArrayAdapter(applicationContext, R.layout.support_simple_spinner_dropdown_item, category)
        spinnerCatEdit.adapter = adapter

        val categoryType = intArrayOf(0)
        spinnerCatEdit.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                categoryType[0] = categoryId[parent.getPositionForView(view)]
                Toast.makeText(applicationContext, "Id : " + categoryType[0], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }



        addImg.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                openGallery(SELECT_PHOTO)
            } else {
                val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                ActivityCompat.requestPermissions(this,permissions,SELECT_PHOTO)
            }
        }

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        releaseYearEdit.setOnClickListener {
            val picker = DatePickerDialog(this,{
                    _, year, month, day ->
                releaseYearEdit.setText("$day/${month+1}/$year")
            },year,month,day)
            picker.show()
        }

        update.setOnClickListener {
            val img: ByteArray = convertImg(imageViewEdit)!!
            val category = spinnerCatEdit.selectedItem.toString()
            val book = bookNameEdit.text.toString()
            val author = authorNameEdit.text.toString()
            val year = releaseYearEdit.text.toString()
            val pagesNum = pagesEdit.text.toString()
            if (book == "") {
                Toast.makeText(this, "Invalid Book Name", Toast.LENGTH_SHORT).show()
            }
            if (author == "") {
                Toast.makeText(this, "Invalid Author Name", Toast.LENGTH_SHORT).show()
            }
            val result = db.updateBook(books.id,book,author,year,pagesNum,img,0,categoryType[0].toLong())
            if (result){
                Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this,Library::class.java))
            } else{
                Toast.makeText(this, "Error occurred", Toast.LENGTH_SHORT).show()
            }
            bookNameEdit.setText("")
            authorNameEdit.setText("")
            releaseYearEdit.setText("")
            pagesEdit.setText("")
            imageViewEdit.setImageResource(R.drawable.ic_baseline_menu_book_24)
        }
    }

    fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Add Book"
        initViews()
    }
    fun initViews() {
        imageViewEdit = findViewById<View>(R.id.imageViewEdit) as ImageView
        addImg = findViewById<View>(R.id.addImg) as ImageButton
        spinnerCatEdit = findViewById<View>(R.id.spinner_catEdit) as Spinner
        bookNameEdit = findViewById<View>(R.id.bookNameEdit) as EditText
        authorNameEdit = findViewById<View>(R.id.authorNameEdit) as EditText
        releaseYearEdit = findViewById<View>(R.id.releaseYearEdit) as EditText
        pagesEdit = findViewById<View>(R.id.pagesEdit) as EditText
        update = findViewById<View>(R.id.update) as Button
        bookNameEdit.setText(books.name)
        authorNameEdit.setText(books.author)
        releaseYearEdit.setText(books.year)
        pagesEdit.setText(books.pages)
        val img: ByteArray = books.image
        val bmp = BitmapFactory.decodeByteArray(img, 0, img.size)
        imageViewEdit.setImageBitmap(Bitmap.createScaledBitmap(bmp, 100, 100, false))
    }

    fun openGallery(requestCode: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        startActivityForResult(i, requestCode)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 0) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                imageViewEdit.isEnabled = true
            }
        }
    }

    @JvmName("onActivityResult1")
    protected fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode ==SELECT_PHOTO) {
            if (resultCode == RESULT_OK) {
                try {
                    val imageUri = data.data
                    val imageStream = contentResolver.openInputStream(imageUri!!)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageViewEdit.setImageBitmap(selectedImage)
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
            }
        }
    }


    private fun convertImg(view: View?): ByteArray? {
        imageViewEdit.isDrawingCacheEnabled = true
        imageViewEdit.buildDrawingCache()
        val bitmap = imageViewEdit.drawingCache
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()
        Toast.makeText(this, "Image saved to DB successfully", Toast.LENGTH_SHORT).show()
        return data
    }

}