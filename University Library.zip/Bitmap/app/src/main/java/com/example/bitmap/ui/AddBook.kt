package com.example.bitmap.ui


import android.Manifest
import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.R
import com.example.bitmap.model.Book
import java.io.ByteArrayOutputStream
import java.io.FileNotFoundException
import java.util.*

class AddBook : AppCompatActivity() {

    private lateinit var actionBar: ActionBar
    private lateinit var imageView: ImageView
    private lateinit var addImg: ImageButton
    private lateinit var spinnerCat: Spinner
    private lateinit var bookName: EditText
    private lateinit var authorName: EditText
    private lateinit var releaseYear: EditText
    private lateinit var pages: EditText
    private lateinit var create: Button
    private val SELECT_PHOTO = 1
    private lateinit var db: MyDataBase

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_book)
        actionBar()
        db = MyDataBase(applicationContext)
        val category = db.getCategoryName()
        val categoryId: ArrayList<Int> = db.getCategoryById()
        var adapterSpinner=ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item,category)
        spinnerCat.adapter = adapterSpinner
        val categoryType = intArrayOf(0)

        spinnerCat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                categoryType[0] = categoryId[parent.getPositionForView(view)]
                Toast.makeText(applicationContext, "Id : " + categoryType[0], Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }


        addImg.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                openGallery(SELECT_PHOTO)
            } else {
                val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                ActivityCompat.requestPermissions(this, permissions,SELECT_PHOTO)
            }
        }

        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        releaseYear.setOnClickListener {
            val picker = DatePickerDialog(this,{
                    _, year, month, day ->
                releaseYear.setText("$day/${month+1}/$year")
            },year,month,day)
            picker.show()
        }

        create.setOnClickListener {
            val img: ByteArray = convertImg(imageView)!!
//            String category = spinnerCat.getSelectedItem().toString();
            val book = bookName.text.toString()
            val author = authorName.text.toString()
            val year = releaseYear.text.toString()
            val pagesNum = pages.text.toString()
            Toast.makeText(applicationContext, "img $img", Toast.LENGTH_SHORT).show()
            if (book == "") {
                Toast.makeText(this, "Invalid Book Name", Toast.LENGTH_SHORT).show()
            }
            if (author == "") {
                Toast.makeText(this, "Invalid Author Name", Toast.LENGTH_SHORT).show()
            }
            val result = db.insertBook(Book(book, author, year, pagesNum, img, 0, categoryType[0].toLong()))
            if (result) {
                Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(this, "Error occurred", Toast.LENGTH_SHORT).show()
            }
            bookName.setText("")
            authorName.setText("")
            releaseYear.setText("")
            pages.setText("")
        }
//        Toast.makeText(this,"Toast",Toast.LENGTH_SHORT).show()

    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String?>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 0) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                imageView.isEnabled = true
            }
        }
    }

    @JvmName("onActivityResult1")
     fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SELECT_PHOTO) {
            if (resultCode == RESULT_OK) {
                try {
                    val imageUri = data.data
                    val imageStream = contentResolver.openInputStream(imageUri!!)
                    val selectedImage = BitmapFactory.decodeStream(imageStream)
                    imageView.setImageBitmap(selectedImage)
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                }
            }
        }
    }


    private fun convertImg(view: View?): ByteArray? {
        imageView.isDrawingCacheEnabled = true
        imageView.buildDrawingCache()
        val bitmap = imageView.drawingCache
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()
        Toast.makeText(this, "Image saved to DB successfully", Toast.LENGTH_SHORT).show()
        return data
    }

    private fun openGallery(requestCode: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        startActivityForResult(i, requestCode)
    }

    fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Add Book"
        initViews()
    }
    fun initViews() {
        imageView = findViewById<ImageView>(R.id.imageView)
        addImg = findViewById<ImageButton>(R.id.addImg)
        spinnerCat = findViewById<Spinner>(R.id.spinner_cat)
        bookName = findViewById<EditText>(R.id.bookName)
        authorName = findViewById<EditText>(R.id.authorName)
        releaseYear = findViewById<EditText>(R.id.releaseYear)
        pages = findViewById<EditText>(R.id.pages)
        create = findViewById<Button>(R.id.create)
    }
}