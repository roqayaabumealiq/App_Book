package com.example.bitmap.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import com.example.bitmap.ui.Favourite
import java.util.ArrayList

class FavouriteAdapter(favouriteArrayList: ArrayList<Book>, context: Context) :
    RecyclerView.Adapter<FavouriteAdapter.FavouriteViewHolder>() {
    var favouriteArrayList: ArrayList<Book> = favouriteArrayList
    var context: Context = context
    var helper: MyDataBase = MyDataBase(context)

    class FavouriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var bookImg: ImageView = itemView.findViewById(R.id.bookImgF)
        var bookTitle: TextView = itemView.findViewById(R.id.bookTitleF)
        var bookReleaseYear: TextView = itemView.findViewById(R.id.bookYearF)
        var fav: Button = itemView.findViewById(R.id.fav_buttonF)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavouriteViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view: View = layoutInflater.inflate(R.layout.favourite_item, null, false)
        return FavouriteViewHolder(view)
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onBindViewHolder(
        holder: FavouriteViewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        val newPosition = position
        val book: Book = favouriteArrayList[position]
        holder.bookTitle.text = book.name
        holder.bookReleaseYear.text = book.year
        val img: ByteArray = book.image
        val bmp = BitmapFactory.decodeByteArray(img, 0, img.size)
        holder.bookImg.setImageBitmap(Bitmap.createScaledBitmap(bmp, 100, 100, false))
        holder.fav.setOnClickListener(View.OnClickListener {
            holder.fav.background = context.getDrawable(R.drawable.ic_baseline_favorite_border_24)
            if (helper.deleteFavourite(book)) {
                //                    notifyDataSetChanged();
                context.startActivity(Intent(context, Favourite::class.java))
                Toast.makeText(context, "Delete Favorite", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Fail Delete Favorite", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun getItemCount(): Int {
        return favouriteArrayList.size
    }

}