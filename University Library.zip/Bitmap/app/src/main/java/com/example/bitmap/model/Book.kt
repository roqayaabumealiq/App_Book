package com.example.bitmap.model

import java.io.Serializable

class Book : Serializable {
    var id: Long = 0
    var name: String
    var author: String
    var year: String
    var pages: String
    var image: ByteArray
    var favourite: Int
    var cat_Id: Long

    constructor(name: String, author: String, year: String, pages: String, image: ByteArray, favourite: Int, Cat_Id: Long) {
        this.name = name
        this.author = author
        this.year = year
        this.pages = pages
        this.image = image
        this.favourite = favourite
        cat_Id = Cat_Id
    }

    constructor(id: Long, name: String, author: String, year: String, pages: String, image: ByteArray, favourite: Int, Cat_Id: Long) {
        this.id = id
        this.name = name
        this.author = author
        this.year = year
        this.pages = pages
        this.image = image
        this.favourite = favourite
        cat_Id = Cat_Id
    }
}
