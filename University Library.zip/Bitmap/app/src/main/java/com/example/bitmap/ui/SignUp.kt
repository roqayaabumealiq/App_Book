package com.example.bitmap.ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bitmap.R

class SignUp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val inputName: EditText =findViewById(R.id.signup_inputName)
        val inputEmail: EditText =findViewById(R.id.signup_inputEmail)
        val inputPassword: EditText =findViewById(R.id.signup_inputPassword)
        val btnLogin: Button =findViewById(R.id.signup_btnLogin)
        val btnRegister: Button =findViewById(R.id.btnLogin)
        btnLogin.setOnClickListener {
            startActivity(Intent(this,Login::class.java))
        }

        btnRegister.setOnClickListener {
            val pref: SharedPreferences = getSharedPreferences("countSharedPref", MODE_PRIVATE)
            val editor = pref.edit()
            editor.putString("name",inputName.text.toString())
            editor.putString("email",inputEmail.text.toString())
            editor.putString("password",inputPassword.text.toString())
            editor.apply()
            Toast.makeText(this,"yes", Toast.LENGTH_SHORT).show()
            inputName.text.clear()
            inputEmail.text.clear()
            inputPassword.text.clear()
            startActivity(Intent(this,MainActivity::class.java))
        }

    }
}