package com.example.bitmap.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bitmap.R
import com.example.bitmap.fragment.SearchFragment

class SearchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        val edSearch=findViewById<EditText>(R.id.input_search)
        val btnSearch=findViewById<Button>(R.id.btn_search)


        val key=edSearch.text.toString()
        val b=Bundle()
        b.putString("key",key)
        val s= SearchFragment()
        s.arguments=b
        supportFragmentManager.beginTransaction().replace(R.id.frame_layout,s).commit()


        btnSearch.setOnClickListener {
            if (edSearch.text.toString().isEmpty()){
                edSearch.error
            }else{
                val key=edSearch.text.toString().trim()
                val b=Bundle()
                b.putString("key",key)
                val s= SearchFragment()
                s.arguments=b
                supportFragmentManager.beginTransaction().replace(R.id.frame_layout,s).commit()

            }
        }


    }
}