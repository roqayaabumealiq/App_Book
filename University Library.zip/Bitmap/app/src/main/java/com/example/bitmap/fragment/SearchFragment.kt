package com.example.bitmap.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.adapter.AdapterSearch
import com.example.bitmap.databasi.MyDataBase


class SearchFragment : Fragment() {

    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val root= inflater.inflate(R.layout.fragment_search, container, false)
        val recycler=root.findViewById<RecyclerView>(R.id.recycler_search)
        val helper=MyDataBase(requireContext())
        val text=arguments?.getString("key")
        val array=helper.searchForData(text!!)

        viewAdapter = AdapterSearch(array,requireContext())
        viewManager = LinearLayoutManager(requireContext())
        recycler.apply {
            setHasFixedSize(true)
            adapter = viewAdapter
            layoutManager = viewManager
            val itemDecoration = DividerItemDecoration(this.context, DividerItemDecoration.VERTICAL)
            addItemDecoration(itemDecoration)

        }
        return root
    }

}