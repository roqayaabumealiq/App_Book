package com.example.bitmap.ui
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import com.example.bitmap.R
import kotlin.system.exitProcess


class MainActivity : AppCompatActivity() {

    private lateinit var library: CardView
    private lateinit var favourite: CardView
    private lateinit var addBook: CardView
    private lateinit var createCategory: CardView
    private lateinit var search: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val actionBar: ActionBar? = supportActionBar
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar!!.setBackgroundDrawable(colorDrawable)
        title = "University's library"

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            //Ask User
            Log.i("moh", "Ask User")
            val permission = arrayOfNulls<String>(1)
            permission[0] = Manifest.permission.READ_EXTERNAL_STORAGE
            ActivityCompat.requestPermissions(this, permission, 1212)
        } else {
            Log.i("moh", "Granted")
        }

        library = findViewById(R.id.library)
        favourite = findViewById(R.id.favourite)
        addBook = findViewById(R.id.addBook)
        createCategory = findViewById(R.id.createCategory)
        search = findViewById(R.id.search)


        library.setOnClickListener {
            val i = Intent(applicationContext, Library::class.java)
            startActivity(i)
        }
        favourite.setOnClickListener {
             val i = Intent(applicationContext, Favourite::class.java)
             startActivity(i)
        }


        addBook.setOnClickListener {
            val i = Intent(applicationContext, AddBook::class.java)
            startActivity(i)
        }

        createCategory.setOnClickListener {
            val i = Intent(applicationContext, CreateCategory::class.java)
            startActivity(i)
        }

        search.setOnClickListener {
            val i = Intent(applicationContext, SearchActivity::class.java)
            startActivity(i)
        }



    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.app_bar_search ->{
                exitProcess(-1)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}