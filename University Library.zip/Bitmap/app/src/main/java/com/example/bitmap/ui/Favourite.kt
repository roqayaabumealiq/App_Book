package com.example.bitmap.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.adapter.FavouriteAdapter
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import java.util.ArrayList

class Favourite : AppCompatActivity() {

    private lateinit var actionBar: ActionBar
    private lateinit var helper: MyDataBase
    private lateinit var reFavorite: RecyclerView
    private lateinit var adapter: FavouriteAdapter
    private lateinit var booksFavorite: ArrayList<Book>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favourite)

        actionBar()
        helper = MyDataBase(this)
        booksFavorite = helper.getBookFavorite()!!
        reFavorite = findViewById(R.id.rv_favourite)

        if (booksFavorite != null){
            loadRecycler()
        } else{
            Toast.makeText(this,"Error occurred",Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadRecycler() {
        adapter = FavouriteAdapter(booksFavorite, this)
        val lManager = LinearLayoutManager(this)
        lManager.orientation = LinearLayoutManager.VERTICAL
        reFavorite.adapter = adapter
        reFavorite.layoutManager = lManager
    }

    private fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Favourite"
    }


}