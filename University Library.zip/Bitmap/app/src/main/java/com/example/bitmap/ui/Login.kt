package com.example.bitmap.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.bitmap.R

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val pref = getSharedPreferences("countSharedPref", MODE_PRIVATE)
        var email=pref.getString("email","null email")
        var password=pref.getString("password","null password")

        val btnCreate=findViewById<Button>(R.id.login_btnCreate)
        val btnLogin=findViewById<Button>(R.id.btnLogin)
        val inputEmail=findViewById<EditText>(R.id.login_inputEmail)
        val inputPassword=findViewById<EditText>(R.id.login_inputPassword)
        btnCreate.setOnClickListener {
            startActivity(Intent(this,SignUp::class.java))
        }

        btnLogin.setOnClickListener {
            val editEmail=inputEmail.text.toString()
            val editPassword=inputPassword.text.toString()
            if (editEmail == email && editPassword == password){
                startActivity(Intent(this,MainActivity::class.java))
                inputEmail.text.clear()
                inputPassword.text.clear()
            }else{
                inputEmail.text.clear()
                inputPassword.text.clear()
                inputEmail.error = "Email is wrong"
                inputPassword.error = "password is wrong"
                Toast.makeText(this,"If you do not have an account, please register a new account",
                    Toast.LENGTH_SHORT).show()
            }
//            Toast.makeText(this,"$email\n$password",Toast.LENGTH_SHORT).show()
        }


    }
}