package com.example.bitmap.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import com.example.bitmap.R
import com.example.bitmap.ui.Login
import com.example.bitmap.ui.MainActivity
import com.example.bitmap.ui.SignUp

class Splash : AppCompatActivity() {
    private lateinit var top_anim: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val actionBar: ActionBar? = supportActionBar
        actionBar!!.hide()
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        Handler().postDelayed({
            val i = Intent(applicationContext, SignUp::class.java)
            startActivity(i)
            finish()
        }, 2500)

    }
    override fun onStart() {
        super.onStart()
        top_anim = AnimationUtils.loadAnimation(this, R.anim.top_animation)
        val txt = findViewById<TextView>(R.id.splash_title)
        txt.animation = top_anim
    }
}