package com.example.bitmap.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import com.example.bitmap.ui.BookDetailes
import java.util.ArrayList

class AdapterSearch(var bookArrayList: ArrayList<Book>, var context: Context) :
    RecyclerView.Adapter<AdapterSearch.MyViewHolder>() {
    private val helper = MyDataBase(context)
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val bookImg: ImageView = itemView.findViewById(R.id.bookImgS)
        val bookTitle: TextView = itemView.findViewById(R.id.bookTitleS)
        val bookReleaseYear: TextView = itemView.findViewById(R.id.bookYearS)
        val fav: Button = itemView.findViewById(R.id.fav_buttonS)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.item_search, null, false)
        return MyViewHolder(view)
    }

    @SuppressLint("UseCompatLoadingForDrawables") override fun onBindViewHolder(holder: MyViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val book = bookArrayList[position]
        holder.bookTitle.text = book.name
        holder.bookReleaseYear.text = book.year
        val img: ByteArray = book.image
        val bmp = BitmapFactory.decodeByteArray(img, 0, img.size)
        holder.bookImg.setImageBitmap(Bitmap.createScaledBitmap(bmp, 100, 100, false))
        holder.itemView.setOnClickListener {
            val i = Intent(context, BookDetailes::class.java)
            i.putExtra("Book", book)
            context.startActivity(i)
        }



        holder.fav.setOnClickListener {
            holder.fav.background = context.getDrawable(R.drawable.favourite)
            if (helper.insertFavorite(book)) {
                Toast.makeText(context, "Insert Favorite", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Fail Insert Favorite", Toast.LENGTH_SHORT).show()
            }
        }


    }

    override fun getItemCount(): Int {
        return bookArrayList.size
    }
}