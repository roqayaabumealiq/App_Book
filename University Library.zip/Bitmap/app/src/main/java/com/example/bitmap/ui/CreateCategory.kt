package com.example.bitmap.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import com.example.bitmap.R
import com.example.bitmap.databasi.MyDataBase

class CreateCategory : AppCompatActivity() {
    private lateinit var actionBar: ActionBar
    private lateinit var catName: EditText
    private lateinit var addCat: Button
    private lateinit var db: MyDataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_category)
        actionBar()
        initViews()
        db = MyDataBase(applicationContext)
        addCat.setOnClickListener {
            val catTitle = catName.text.toString()
            if (catTitle == "") catName.error = "Add category"
            val result = db.insertCategory(catTitle)
            if (result){
                Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(this, "Error occurred", Toast.LENGTH_SHORT).show()
            }
            catName.setText("")
        }

    }

    fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Create Category"
    }

    fun initViews() {
        catName = findViewById<View>(R.id.cat_Name) as EditText
        addCat = findViewById<View>(R.id.addCat) as Button
    }

}