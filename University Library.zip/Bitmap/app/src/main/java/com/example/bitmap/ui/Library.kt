package com.example.bitmap.ui

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.adapter.CategoryAdapter
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Category
import java.util.*


class Library : AppCompatActivity() {
    private lateinit var actionBar: ActionBar
    private lateinit var rvLibrary: RecyclerView
      private lateinit var adapter: CategoryAdapter
    lateinit var cats: ArrayList<Category>
    lateinit var db: MyDataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)
        actionBar()
        db = MyDataBase(this)
        rvLibrary = findViewById<RecyclerView>(R.id.rv_library)
        cats = db.allCategory
        if (cats != null) {
            loadRecycler()
        } else {
            Toast.makeText(this, "Error occurred", Toast.LENGTH_SHORT).show()
        }
    }
    fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar!!.setBackgroundDrawable(colorDrawable)
        title = "Library"
    }

    private fun loadRecycler() {
        adapter = CategoryAdapter(cats, this)
        val lmanager = LinearLayoutManager(this)
        lmanager.orientation = LinearLayoutManager.VERTICAL
        rvLibrary.adapter = adapter
        rvLibrary.layoutManager = lmanager
        Log.d("Malak", "Done")
    }
}



