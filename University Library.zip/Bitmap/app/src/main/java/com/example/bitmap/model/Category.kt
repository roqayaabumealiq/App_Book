package com.example.bitmap.model

import java.io.Serializable

class Category(  var id: Long,var name: String) : Serializable {
}
