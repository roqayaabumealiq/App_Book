package com.example.bitmap.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.ui.Category_Book
import com.example.bitmap.R
import com.example.bitmap.model.Category
import java.util.ArrayList

class CategoryAdapter(var categoryArrayList: ArrayList<Category>, var context: Context) :
    RecyclerView.Adapter<CategoryAdapter.MyViewHolder>() {

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val catName: TextView = itemView.findViewById(R.id.lib_cat)
        val linearClick: LinearLayout = itemView.findViewById(R.id.linearClick)


    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.library_item, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val category = categoryArrayList[position]
        holder.catName.text = category.name
        holder.linearClick.setOnClickListener(View.OnClickListener {

            val i = Intent(context, Category_Book::class.java)
            i.putExtra("Category", category.id)
            context.startActivity(i)
        })
    }


    override fun getItemCount(): Int {
        return categoryArrayList.size
    }
}