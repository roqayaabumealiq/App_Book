package com.example.bitmap.databasi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.bitmap.model.Book
import com.example.bitmap.model.Category
import java.util.*

class MyDataBase(context: Context?) :
    SQLiteOpenHelper(context, DB_Name, null, DB_version) {
    override fun onCreate(db: SQLiteDatabase) {
        //Just once when create DB
        //create category table
        db.execSQL("create  table $cat_table($cat_col_id integer primary key autoincrement, $cat_col_name text unique )")
        //create book table
        db.execSQL("create  table $book_table($book_col_id integer primary key autoincrement, $book_col_name text unique,$book_col_author text not null,$book_col_year text,$book_col_pages text,$book_col_image blob not null,$book_col_fav integer, $book_col_catId integer, FOREIGN KEY ($book_col_catId) REFERENCES $cat_table($cat_col_id) )")
        //create
        db.execSQL("create  table $favorite_table($book_col_id integer primary key , $book_col_name text unique,$book_col_author text not null,$book_col_year text,$book_col_pages text,$book_col_image blob not null,$book_col_fav integer, $book_col_catId integer, FOREIGN KEY ($book_col_catId) REFERENCES $cat_table($cat_col_id) )")


    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $cat_table")
        db.execSQL("DROP TABLE IF EXISTS $book_table")
        db.execSQL("DROP TABLE IF EXISTS $favorite_table")
        onCreate(db)
    }

    fun insertCategory(name:String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(cat_col_name,name)
        val result = db.insert(cat_table, null, values)
        return result != -1L
    }

    //Switch the cursor to ArrayList
    //Check if cursor contain data
    val allCategory: ArrayList<Category>
        get() {
            val categories = ArrayList<Category>()
            val db = readableDatabase
            val c = db.rawQuery("select * from $cat_table", null)
            //Switch the cursor to ArrayList
            //Check if cursor contain data
            if (c.moveToFirst()) {
                do {
                    val id = c.getLong(0)
                    val name = c.getString(1)
                    val category = Category(id,name)
                    category.id
                    categories.add(category)
                } while (c.moveToNext())
                c.close()
            }
            return categories
        }

    fun insertBook(book: Book): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(book_col_name, book.name)
        values.put(book_col_author, book.author)
        values.put(book_col_year, book.year)
        values.put(book_col_pages, book.pages)
        values.put(book_col_image, book.image)
        values.put(book_col_fav, book.favourite)
        values.put(book_col_catId, book.cat_Id)
        val result = db.insert(book_table, null, values)
        return result != -1L
    }

    fun insertFavorite(book: Book): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(book_col_id, book.id)
        values.put(book_col_name, book.name)
        values.put(book_col_author, book.author)
        values.put(book_col_year, book.year)
        values.put(book_col_pages, book.pages)
        values.put(book_col_image, book.image)
        values.put(book_col_fav, book.favourite)
        values.put(book_col_catId, book.cat_Id)
        val result = db.insert(favorite_table, null, values)
        return result != -1L
    }


    fun deleteBook(book: Book): Boolean {
        val db = writableDatabase
        val args = arrayOf<String>(book.id.toString() + "")
        val result = db.delete(book_table, "$book_col_id=?", args)
        //result = num of rows
        return result > 0
    }

    fun deleteFavourite(book: Book): Boolean {
        val db = writableDatabase
        val args = arrayOf<String>(book.id.toString() + "")
        val result = db.delete(favorite_table, "$book_col_id=?", args)
        //result = num of rows
        return result > 0
    }

    fun updateBook(id: Long, name: String?, author: String?, year: String?, pages: String?, img: ByteArray?, fav: Int, cat_id: Long): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        val args = arrayOf(id.toString())
        values.put(book_col_name, name)
        values.put(book_col_author, author)
        values.put(book_col_year, year)
        values.put(book_col_pages, pages)
        values.put(book_col_image, img)
        values.put(book_col_fav, fav)
        values.put(book_col_catId, cat_id)
        return db.update(book_table, values, "$book_col_id=?", args) > 0
    }



    fun getCategoryName():ArrayList<String>{
        val category=ArrayList<String>()
        val db:SQLiteDatabase=readableDatabase
        val c=db.rawQuery("select $cat_col_name from $cat_table", null)
        if (c.moveToFirst()) {
            do {
                category.add(c.getString(0))
            } while (c.moveToNext())
            c.close()
        }
        return category
    }

    fun getCategoryById():ArrayList<Int>{
        val category=ArrayList<Int>()
        val db:SQLiteDatabase=readableDatabase
        val c=db.rawQuery("select $cat_col_id from $cat_table", null)
        if (c.moveToFirst()) {
            do {
                category.add(c.getInt(0))
            } while (c.moveToNext())
            c.close()
        }
        return category
    }

    fun getBook(id: Long): ArrayList<Book> {
        val books = ArrayList<Book>()
        val db = readableDatabase
        val args = arrayOf(id.toString())
        val c =db.rawQuery("select * from $book_table where $book_col_catId = ?", args)
        if (c.moveToFirst()) {
            do {
                books.add(
                    Book(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getBlob(5), c.getInt(6), c.getLong(7))
                )
            } while (c.moveToNext())
            c.close()
        }
        return books
    }

    fun getBookFavorite(): ArrayList<Book>? {
        val books = ArrayList<Book>()
        val db = readableDatabase
        val c = db.rawQuery("select * from $favorite_table", null)
        if (c.moveToFirst()) {
            do {
                books.add(Book(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getBlob(5), c.getInt(6), c.getLong(7)))
            } while (c.moveToNext())
            c.close()
        }
        return books
    }

    fun searchForData(keyword:String) : ArrayList<Book> {
        val data = ArrayList<Book>()
        val db=readableDatabase
        val cursor = db.rawQuery("select * from $book_table where $book_col_name like \"%$keyword%\" order by $book_col_id desc", null)
        cursor.moveToFirst()
        while (!cursor.isAfterLast) {
            data.add(Book(cursor.getLong(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getBlob(5),cursor.getInt(6),cursor.getLong(7)))
            cursor.moveToNext()
        }
        cursor.close()
        return data
    }


    companion object {
        const val DB_Name = "library_DB"
        const val DB_version = 1

        //Category table and it's colms
        const val cat_table = "category"
        const val cat_col_name = "cat_name"
        const val cat_col_id = "id"

        //Book table and it's colms
        const val book_table = "book"
        const val book_col_id = "id"
        const val book_col_name = "book_name"
        const val book_col_author = "author_name"
        const val book_col_year = "releases_year"
        const val book_col_image = "image"
        const val book_col_pages = "pages"
        const val book_col_fav = "favourite"
        const val book_col_catId = "cat_id"

        //Favorite table
        const val favorite_table = "Favorite"


    }
}
