package com.example.bitmap.ui

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.bitmap.R
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import java.lang.String

class BookDetailes : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var bookname: TextView
    private lateinit var authorname: TextView
    private lateinit var yearRelease: TextView
    private lateinit var pages: TextView
    private lateinit var categorys: TextView
    private lateinit var edits: Button
    private lateinit var actionBar: ActionBar
    private lateinit var book: Book
    private lateinit var db: MyDataBase
    private lateinit var categoryName: ArrayList<kotlin.String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_detailes)
        actionBar()
        initViews()
        db= MyDataBase(this)

        if (intent!=null){
            book= intent.getSerializableExtra("Book") as Book
        }else{
            Toast.makeText(this,"No Fond Data",Toast.LENGTH_SHORT).show()
        }

        setValues()

        edits.setOnClickListener {
            val i = Intent(applicationContext, EditBook::class.java)
            i.putExtra("Book", book)
            startActivity(i)

        }

    }

    private fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Book Details"
        // actionBar.setDisplayHomeAsUpEnabled(true);
    }
    private fun initViews() {
        imageView = findViewById<ImageView>(R.id.imageView)
        bookname = findViewById<TextView>(R.id.bookname)
        authorname = findViewById<TextView>(R.id.authorname)
        yearRelease = findViewById<TextView>(R.id.yearRelease)
        pages = findViewById<TextView>(R.id.pages)
        categorys = findViewById<TextView>(R.id.categorys)
        edits = findViewById<Button>(R.id.edits)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.delete,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.delete ->{
                val id=book.id
                val builder= AlertDialog.Builder(this)
                builder.setTitle("تنبيه")
                builder.setMessage("سيتم حذف العنصر")
                builder.setIcon(R.drawable.ic_baseline_delete_24)
                builder.setCancelable(false)
                builder.setPositiveButton("موافق"){ _: DialogInterface, _:Int->
                    db.deleteBook(book)
                    val i = Intent(this, Library::class.java)
                    startActivity(i)
                }
                builder.setNegativeButton("الغاء"){ d:DialogInterface, i:Int ->
                    d.cancel()
                }
                val dialog=builder.create()
                dialog.show()


            }
        }
        return super.onOptionsItemSelected(item)
    }
    private fun setValues() {
        bookname.text = book.name
        authorname.text = book.author
        yearRelease.text = book.year
        pages.text = book.pages
        categorys.text = String.valueOf(book.cat_Id)
        val img: ByteArray = book.image
        val bmp = BitmapFactory.decodeByteArray(img, 0, img.size)
        imageView.setImageBitmap(Bitmap.createScaledBitmap(bmp, 100, 100, false))
    }

}