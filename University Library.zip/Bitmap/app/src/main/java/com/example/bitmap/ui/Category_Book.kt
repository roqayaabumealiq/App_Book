package com.example.bitmap.ui


import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.bitmap.R
import com.example.bitmap.adapter.AdapterSearch
import com.example.bitmap.databasi.MyDataBase
import com.example.bitmap.model.Book
import java.util.ArrayList

class Category_Book : AppCompatActivity() {

    private lateinit var actionBar: ActionBar
    private lateinit var rvCat: RecyclerView
    private lateinit var db: MyDataBase
    private lateinit var books: ArrayList<Book>
    private lateinit var adapter: AdapterSearch
    var category: Long = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_book)
        actionBar()


        val  categories= intent.getSerializableExtra("Categories");


        if (intent != null) {
            category = intent.getLongExtra("Category", -1)
        } else {
            Toast.makeText(this, "Intent is empty", Toast.LENGTH_SHORT).show()
        }

        rvCat = findViewById<View>(R.id.rv_Cat) as RecyclerView
        db = MyDataBase(this)
        //        Toast.makeText(this, "Intent ok "+category, Toast.LENGTH_SHORT).show();
//        books = db.getAllBook(category);
        books = db.getBook(category)

        //        Log.i("Mlak","Fine before recycle");
        if (books != null) {
            loadRecycler()
        }else {
            Toast.makeText(this, "Error occurred", Toast.LENGTH_SHORT).show()
        }

    }

    private fun loadRecycler() {
        adapter = AdapterSearch(books, this)
        val lManager = LinearLayoutManager(this)
        lManager.orientation = LinearLayoutManager.VERTICAL
        rvCat.adapter = adapter
        rvCat.layoutManager = lManager
    }

    fun actionBar() {
        actionBar = supportActionBar!!
        val colorDrawable = ColorDrawable(Color.parseColor("#FFBB86FC"))
        actionBar.setBackgroundDrawable(colorDrawable)
        title = "Books"
    }


}